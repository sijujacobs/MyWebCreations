<?php

// Read JSON file
$json = file_get_contents('./fruits.json');

echo $json;

?>